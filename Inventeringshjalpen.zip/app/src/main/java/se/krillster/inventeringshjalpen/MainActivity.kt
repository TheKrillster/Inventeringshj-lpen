package se.krillster.inventeringshjalpen

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : Activity(), CountView.Listener {

    companion object {
        private const val REQ_CAMERA = 1
        private const val REQ_PICK = 2
        private const val REQ_LABEL = 3
        private const val MAX_DIM = 2000

        private const val INK = 0xFF1D1D1B.toInt()
        private const val ACCENT = 0xFFE8541C.toInt()
        private const val BLUE = 0xFF1F5FBF.toInt()
        private const val MUTED = 0xFF6B6A66.toInt()
        private const val LINE = 0xFFDEDCD5.toInt()
        private const val BG = 0xFFF4F3EF.toInt()
    }

    private val ui = Handler(Looper.getMainLooper())

    private var material: Material? = null
    private var bitmap: Bitmap? = null
    private var gray: GrayImage? = null
    private var grayInv: GrayImage? = null
    private var color: ColorImage? = null
    private var sens = 5
    private var onCountScreen = false
    private var busy = false

    // fält i resultatet
    private val fieldKeys = listOf("article", "batch", "description", "location", "comment")
    private val fields = HashMap<String, String>()
    private var fieldViews = HashMap<String, EditText>()

    private lateinit var countView: CountView
    private var countText: TextView? = null
    private var hintText: TextView? = null
    private var materialButton: Button? = null
    private var toolButton: Button? = null
    private var editButton: Button? = null
    private var undoButton: Button? = null
    private var doneButton: Button? = null
    private var sensRow: View? = null
    private var progress: View? = null

    private val dp get() = resources.displayMetrics.density
    private fun Int.dp() = (this * dp).roundToInt()

    // ================= livscykel =================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fieldKeys.forEach { fields[it] = Store.getField(this, it) }
        val mats = Store.materials(this)
        material = mats.firstOrNull { it.id == Store.getLastMaterial(this) } ?: mats.first()
        showHome()
        handleShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShareIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleShareIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val uri = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: return
            loadImage(uri)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (onCountScreen) showHome() else super.onBackPressed()
    }

    // ================= hjälpare för UI =================
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun rounded(color: Int, radius: Int = 12, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = radius * dp
            if (stroke != null) setStroke(1.dp(), stroke)
        }

    private fun btn(label: String, primary: Boolean = false, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (primary) Color.WHITE else INK)
            background = rounded(if (primary) ACCENT else Color.WHITE, 12, if (primary) null else LINE)
            stateListAnimator = null
            setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
            minHeight = 46.dp(); minimumHeight = 46.dp()
            setOnClickListener { onClick() }
        }

    private fun setOn(b: Button?, on: Boolean) {
        b ?: return
        b.background = rounded(if (on) INK else Color.WHITE, 12, if (on) null else LINE)
        b.setTextColor(if (on) Color.WHITE else INK)
    }

    private fun label(s: String, size: Float = 14f, color: Int = INK, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT,
                   weight: Float = 0f, top: Int = 0, right: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = top.dp(); rightMargin = right.dp() }

    // ================= startsidan =================
    private fun showHome() {
        onCountScreen = false
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(INK)
            setPadding(20.dp(), 22.dp(), 20.dp(), 20.dp())
            addView(label("Inventeringshjälpen", 24f, Color.WHITE, true))
            addView(label("Fota – räkna – rätta – rapportera", 14f, 0xFFBBBBBB.toInt()))
        }
        root.addView(header)

        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16.dp(), 16.dp(), 16.dp(), 24.dp()) }
        scroll.addView(col)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        col.addView(label("Vad ska du räkna?", 13f, MUTED, true))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list, lp(top = 6))
        fun renderList() {
            list.removeAllViews()
            for (m in Store.materials(this)) {
                val sel = m.id == material?.id
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(if (sel) 0xFFFFF3EC.toInt() else Color.WHITE, 12, if (sel) ACCENT else LINE)
                    setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
                    addView(label(m.name, 16f, INK, true))
                    val extra = buildString {
                        append(m.method.short)
                        if (m.perMark > 1) append(" · ${m.perMark} st per markering")
                        if (m.article.isNotBlank()) append(" · art ${m.article}")
                    }
                    addView(label(extra, 13f, MUTED))
                    setOnClickListener { material = m; Store.setLastMaterial(this@MainActivity, m.id); renderList() }
                    setOnLongClickListener { editMaterial(m) { renderList() }; true }
                }
                list.addView(card, lp(top = 8))
            }
        }
        renderList()
        val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addRow.addView(btn("+ Ny materialtyp") { editMaterial(null) { renderList() } }, lp(0, weight = 1f, right = 8))
        addRow.addView(btn("Ändra vald") { material?.let { m -> editMaterial(m) { renderList() } } }, lp(0, weight = 1f))
        col.addView(addRow, lp(top = 10))
        col.addView(label("Tips: håll inne på en materialtyp för att ändra eller ta bort den.", 12f, MUTED), lp(top = 6))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE)
            setPadding(16.dp(), 12.dp(), 16.dp(), 16.dp())
        }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(btn("Ta foto", true) { takePhoto(REQ_CAMERA) }, lp(0, weight = 1f, right = 8))
        r1.addView(btn("Välj bild") { pickImage() }, lp(0, weight = 1f))
        actions.addView(r1)
        actions.addView(btn("Historik") { showHistory() }, lp(top = 8))
        root.addView(actions)
        setContentView(root)
    }

    private fun editMaterial(existing: Material?, done: () -> Unit) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20.dp(), 8.dp(), 20.dp(), 0) }
        fun field(hint: String, value: String, number: Boolean = false) = EditText(this).apply {
            setText(value); this.hint = hint; setSingleLine()
            if (number) inputType = InputType.TYPE_CLASS_NUMBER
        }
        col.addView(label("Namn", 12f, MUTED, true))
        val name = field("t.ex. Kartongrör 50 mm", existing?.name ?: "")
        col.addView(name)
        col.addView(label("Hur ska det räknas?", 12f, MUTED, true), lp(top = 10))
        val group = RadioGroup(this)
        val ids = HashMap<Int, Method>()
        Method.values().forEach { m ->
            val rb = RadioButton(this).apply { text = m.label; id = View.generateViewId() }
            ids[rb.id] = m; group.addView(rb)
            if (m == (existing?.method ?: Method.HOLLOW)) rb.isChecked = true
        }
        col.addView(group)
        col.addView(label("Antal per markering (t.ex. 10 om varje markering är en bunt om 10)", 12f, MUTED, true), lp(top = 10))
        val per = field("1", (existing?.perMark ?: 1).toString(), true)
        col.addView(per)
        col.addView(label("Standard-artikelnummer (valfritt)", 12f, MUTED, true), lp(top = 10))
        val art = field("fylls i automatiskt", existing?.article ?: "")
        col.addView(art)
        col.addView(label("Standard-benämning (valfritt)", 12f, MUTED, true), lp(top = 10))
        val desc = field("t.ex. D32 1320mm", existing?.description ?: "")
        col.addView(desc)
        val sensLabel = label("Känslighet: ${existing?.sens ?: 5}", 12f, MUTED, true)
        col.addView(sensLabel, lp(top = 10))
        val sb = SeekBar(this).apply {
            max = 9; progress = (existing?.sens ?: 5) - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sensLabel.text = "Känslighet: ${p + 1}" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(sb)
        val scroll = ScrollView(this).apply { addView(col) }

        val b = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Ny materialtyp" else "Ändra materialtyp")
            .setView(scroll)
            .setPositiveButton("Spara") { _, _ ->
                val n = name.text.toString().trim().ifEmpty { "Material" }
                val m = Material(
                    existing?.id ?: Store.newId(), n, ids[group.checkedRadioButtonId] ?: Method.HOLLOW,
                    sb.progress + 1, per.text.toString().toIntOrNull()?.coerceIn(1, 100000) ?: 1,
                    art.text.toString().trim(), desc.text.toString().trim(),
                )
                Store.upsertMaterial(this, m)
                material = m; Store.setLastMaterial(this, m.id)
                done()
            }
            .setNegativeButton("Avbryt", null)
        if (existing != null) b.setNeutralButton("Ta bort") { _, _ ->
            AlertDialog.Builder(this).setMessage("Ta bort \"${existing.name}\"?")
                .setPositiveButton("Ta bort") { _, _ ->
                    Store.deleteMaterial(this, existing.id)
                    if (material?.id == existing.id) material = Store.materials(this).first()
                    done()
                }.setNegativeButton("Avbryt", null).show()
        }
        b.show()
    }

    // ================= bild in =================
    private fun photoFile(req: Int) = File(cacheDir, if (req == REQ_LABEL) "label.jpg" else "photo.jpg")

    private fun takePhoto(req: Int) {
        val f = photoFile(req)
        f.delete()
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = ClipData.newRawUri("", uri)
        }
        try {
            @Suppress("DEPRECATION") startActivityForResult(i, req)
        } catch (e: ActivityNotFoundException) {
            toast("Hittar ingen kameraapp")
        }
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        try {
            @Suppress("DEPRECATION") startActivityForResult(Intent.createChooser(i, "Välj bild"), REQ_PICK)
        } catch (e: ActivityNotFoundException) {
            toast("Hittar ingen bildväljare")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_CAMERA -> loadImage(Uri.fromFile(photoFile(REQ_CAMERA)))
            REQ_PICK -> data?.data?.let { loadImage(it) }
            REQ_LABEL -> readLabelPhoto(Uri.fromFile(photoFile(REQ_LABEL)))
        }
    }

    private fun decode(uri: Uri, maxDim: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxDim) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val rot = try {
            contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }
        val s = min(1f, maxDim.toFloat() / max(bmp.width, bmp.height))
        if (rot != 0f || s < 1f) {
            val m = Matrix().apply { postScale(s, s); postRotate(rot) }
            val nb = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (nb != bmp) bmp.recycle()
            bmp = nb
        }
        return if (bmp.config == Bitmap.Config.ARGB_8888) bmp else bmp.copy(Bitmap.Config.ARGB_8888, false)
    }

    private fun loadImage(uri: Uri) {
        showCount()
        setBusy(true, "Läser bild…")
        Thread {
            val bmp = try { decode(uri, MAX_DIM) } catch (e: Throwable) { null }
            val c = bmp?.let { toColor(it) }
            val g = c?.let { toGray(it) }
            ui.post {
                setBusy(false)
                if (bmp == null || g == null) { toast("Kunde inte läsa bilden"); showHome(); return@post }
                bitmap = bmp; gray = g; grayInv = null; color = c
                countView.reset()
                countView.bitmap = bmp
                applyMaterialToView()
                runOcr(bmp, auto = true)
            }
        }.start()
    }

    private fun toColor(b: Bitmap): ColorImage {
        val px = IntArray(b.width * b.height)
        b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
        return ColorImage(b.width, b.height, px)
    }

    private fun toGray(ci: ColorImage): GrayImage {
        val w = ci.w; val h = ci.h
        val px = ci.px
        val g = FloatArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            g[i] = 0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)
        }
        return GrayImage(w, h, g)
    }

    private fun inverted(): GrayImage? {
        val g = gray ?: return null
        grayInv?.let { return it }
        val inv = GrayImage(g.w, g.h, FloatArray(g.px.size) { 255f - g.px[it] })
        grayInv = inv
        return inv
    }

    // ================= räkneskärmen =================
    private fun showCount() {
        onCountScreen = true
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(INK); gravity = Gravity.CENTER_VERTICAL
            setPadding(10.dp(), 8.dp(), 14.dp(), 8.dp())
        }
        val mb = Button(this).apply {
            isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
            background = rounded(0xFF3A3936.toInt(), 18); stateListAnimator = null
            setPadding(14.dp(), 6.dp(), 14.dp(), 6.dp()); minHeight = 38.dp(); minimumHeight = 38.dp()
            setOnClickListener { chooseMaterial() }
        }
        materialButton = mb
        top.addView(mb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val ct = label("–", 26f, Color.WHITE, true)
        countText = ct
        top.addView(ct)
        root.addView(top)

        val stage = FrameLayout(this)
        countView = CountView(this)
        countView.listener = this
        stage.addView(countView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val ht = label("", 13f, Color.WHITE).apply {
            background = rounded(0xB8000000.toInt(), 16); setPadding(12.dp(), 6.dp(), 12.dp(), 6.dp())
        }
        hintText = ht
        stage.addView(ht, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = 10.dp() })
        val pg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(0x88000000.toInt())
            addView(ProgressBar(this@MainActivity))
            addView(label("Räknar…", 15f, Color.WHITE, true).apply { tag = "busyText" })
            visibility = View.GONE; isClickable = true
        }
        progress = pg
        stage.addView(pg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(stage, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10.dp(), 8.dp(), 10.dp(), 10.dp()) }
        val sr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sr.addView(label("Känslighet", 13f, MUTED))
        val sb = SeekBar(this).apply {
            max = 9; progress = sens - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { sens = p + 1 }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            tag = "sens"
        }
        sr.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sr.addView(btn("Räkna om") { recount() })
        sensRow = sr
        bottom.addView(sr)
        val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tb = btn("Område") { setTool(if (material?.method == Method.SHEETS) CountView.Tool.LINE else CountView.Tool.AREA) }
        val eb = btn("Rätta") { setTool(CountView.Tool.EDIT) }
        val ub = btn("Ångra") { countView.undo() }
        val db = btn("Klar", true) { showResult() }
        toolButton = tb; editButton = eb; undoButton = ub; doneButton = db
        tr.addView(tb, lp(0, weight = 1f, right = 6))
        tr.addView(eb, lp(0, weight = 1f, right = 6))
        tr.addView(ub, lp(0, weight = 1f, right = 6))
        tr.addView(db, lp(0, weight = 1f))
        bottom.addView(tr, lp(top = 6))
        root.addView(bottom)
        setContentView(root)
        updateCount()
    }

    private fun setBusy(on: Boolean, msg: String = "Räknar…") {
        busy = on
        progress?.visibility = if (on) View.VISIBLE else View.GONE
        (progress?.findViewWithTag<TextView>("busyText"))?.text = msg
    }

    private fun applyMaterialToView() {
        val m = material ?: return
        sens = m.sens
        (sensRow?.findViewWithTag<SeekBar>("sens"))?.progress = sens - 1
        materialButton?.text = "${m.name}  ▾"
        countView.sheetMode = m.method == Method.SHEETS
        toolButton?.text = if (m.method == Method.SHEETS) "Linje" else "Område"
        toolButton?.visibility = if (m.method == Method.MANUAL) View.GONE else View.VISIBLE
        sensRow?.visibility = if (m.method == Method.MANUAL) View.GONE else View.VISIBLE
        if (m.method == Method.MANUAL) {
            countView.markSize = (bitmap?.let { max(it.width, it.height) } ?: 1000) / 40f
        }
        setTool(when (m.method) {
            Method.SHEETS -> CountView.Tool.LINE
            Method.MANUAL -> CountView.Tool.EDIT
            else -> CountView.Tool.AREA
        })
        updateCount()
    }

    private fun setTool(t: CountView.Tool) {
        countView.tool = t
        setOn(toolButton, t != CountView.Tool.EDIT)
        setOn(editButton, t == CountView.Tool.EDIT)
        hintText?.text = when (t) {
            CountView.Tool.AREA -> if (material?.method == Method.LOOSE)
                "Dra en ruta innanför lådans kanter"
            else "Dra en ruta runt det som ska räknas"
            CountView.Tool.LINE -> "Dra en linje tvärs över stapeln, från översta till understa skivan"
            CountView.Tool.EDIT -> if (material?.method == Method.SHEETS)
                "Tryck nära linjen: lägg till / ta bort · Nyp: zooma"
            else "Tryck: lägg till / ta bort · Dra: flytta · Nyp: zooma"
        }
    }

    private fun chooseMaterial() {
        val mats = Store.materials(this)
        val names = mats.map { "${it.name}  (${it.method.short})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Vad räknar du?")
            .setItems(names) { _, i ->
                val m = mats[i]
                if (m.id == material?.id) return@setItems
                material = m; Store.setLastMaterial(this, m.id)
                countView.reset()
                applyMaterialToView()
            }
            .setNeutralButton("Ny materialtyp") { _, _ ->
                editMaterial(null) { countView.reset(); applyMaterialToView() }
            }
            .show()
    }

    override fun onArea(r: RectF) {
        val m = material ?: return
        val g = (if (m.method == Method.SOLID) inverted() else gray) ?: return
        val ci = color ?: return
        if (busy) return
        setBusy(true)
        val s = sens
        Thread {
            val res = try {
                if (m.method == Method.LOOSE) LooseDetector.detect(ci, r.left, r.top, r.right, r.bottom, s)
                else CircleDetector.detect(g, r.left, r.top, r.right, r.bottom, s)
            } catch (e: Throwable) { CircleResult(emptyList(), 0f) }
            ui.post {
                setBusy(false)
                if (res.diameter > 0) countView.markSize = res.diameter
                countView.setAuto(res.points)
                setTool(CountView.Tool.EDIT)
                toast(if (res.points.isEmpty()) "Hittade inget – prova högre känslighet eller tryck själv" else "${res.points.size} hittade – kontrollera och rätta")
            }
        }.start()
    }

    override fun onLine(p0: Pt, p1: Pt) {
        val g = gray ?: return
        if (busy) return
        setBusy(true)
        val s = sens
        Thread {
            val res = try { SheetDetector.detect(g, p0, p1, s) } catch (e: Throwable) { SheetResult(emptyList(), 0f) }
            ui.post {
                setBusy(false)
                if (res.pitch > 0) countView.markSize = res.pitch * 0.85f
                countView.setAuto(res.points)
                setTool(CountView.Tool.EDIT)
                toast(if (res.points.isEmpty()) "Hittade inga skivor – dra linjen tvärs över kanterna" else "${res.points.size} skivor – zooma in och kontrollera")
            }
        }.start()
    }

    private fun recount() {
        val m = material ?: return
        if (m.method == Method.SHEETS) {
            val l = countView.line ?: run { toast("Dra först en linje"); return }
            onLine(l.first, l.second)
        } else {
            val r = countView.area ?: run { toast("Dra först en ruta"); return }
            onArea(r)
        }
    }

    override fun onMarksChanged() = updateCount()

    private fun stats(): IntArray {
        val auto = countView.marks.count { it.auto }
        val manual = countView.marks.size - auto
        val removed = max(0, countView.autoCount - auto)
        val per = material?.perMark ?: 1
        return intArrayOf(countView.marks.size * per, auto, manual, removed, countView.marks.size)
    }

    private fun updateCount() {
        if (!onCountScreen) return
        val st = stats()
        countText?.text = if (bitmap == null) "–" else "${st[0]} st"
        undoButton?.isEnabled = countView.canUndo
        undoButton?.alpha = if (countView.canUndo) 1f else 0.4f
        doneButton?.isEnabled = st[4] > 0
        doneButton?.alpha = if (st[4] > 0) 1f else 0.4f
    }

    // ================= etikett (OCR) =================
    private fun runOcr(bmp: Bitmap, auto: Boolean) {
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t ->
                val info = LabelParser.parse(t.text)
                val m = material
                // nytt foto: töm fälten som hör till förra räkningen
                if (auto) {
                    fields["article"] = m?.article ?: ""
                    fields["description"] = m?.description ?: ""
                    fields["batch"] = ""
                    fields["comment"] = ""
                }
                info.article?.let { fields["article"] = it }
                info.batch?.let { fields["batch"] = it }
                info.description?.let { fields["description"] = it }
                info.location?.let { fields["location"] = it }
                fieldKeys.forEach { k -> fieldViews[k]?.setText(fields[k] ?: "") }
                if (!info.isEmpty()) {
                    toast("Etikett läst: " + listOfNotNull(info.article, info.batch?.let { "batch $it" }).joinToString(" · ").ifEmpty { "delvis" })
                } else if (!auto) toast("Hittade ingen läsbar text – skriv in för hand")
            }
            .addOnFailureListener { if (!auto) toast("Textigenkänning misslyckades") }
            .addOnCompleteListener { rec.close() }
    }

    private fun readLabelPhoto(uri: Uri) {
        Thread {
            val b = try { decode(uri, 1600) } catch (e: Throwable) { null }
            ui.post { if (b != null) runOcr(b, auto = false) else toast("Kunde inte läsa etikettbilden") }
        }.start()
    }

    // ================= resultat =================
    private fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale("sv", "SE")).format(Date())

    private fun report(time: String): String {
        val st = stats()
        val m = material
        val per = m?.perMark ?: 1
        val sb = StringBuilder()
        sb.append("RÄKNING – ${m?.name ?: ""}\n")
        sb.append("Datum:       $time\n")
        sb.append("Artikelnr:   ${fields["article"].orEmpty().ifBlank { "–" }}\n")
        sb.append("Benämning:   ${fields["description"].orEmpty().ifBlank { "–" }}\n")
        sb.append("Batchnr:     ${fields["batch"].orEmpty().ifBlank { "–" }}\n")
        sb.append("Lagerplats:  ${fields["location"].orEmpty().ifBlank { "–" }}\n")
        sb.append("Antal:       ${st[0]} st")
        if (per > 1) sb.append("  (${st[4]} markeringar × $per)")
        sb.append("\n")
        if (st[2] > 0 || st[3] > 0) sb.append("             (auto ${st[1]}, +${st[2]} tillagda, −${st[3]} borttagna)\n")
        val c = fields["comment"].orEmpty()
        if (c.isNotBlank()) sb.append("Kommentar:   $c\n")
        return sb.toString().trimEnd()
    }

    private fun exportBitmap(time: String): Bitmap? {
        val st = stats()
        val h1 = listOf(fields["article"].orEmpty(), fields["description"].orEmpty()).filter { it.isNotBlank() }
            .joinToString("  ").ifBlank { material?.name ?: "" } +
            (fields["batch"].orEmpty().takeIf { it.isNotBlank() }?.let { "   Batch $it" } ?: "")
        val h2 = "${st[0]} st · ${material?.name ?: ""}" +
            (fields["location"].orEmpty().takeIf { it.isNotBlank() }?.let { " · $it" } ?: "") + " · $time"
        return countView.renderExport(h1, h2)
    }

    private fun showResult() {
        val time = now()
        val st = stats()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20.dp(), 12.dp(), 20.dp(), 4.dp()) }
        val sum = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(0xFFFFF3EC.toInt(), 12, 0xFFF6CDB8.toInt())
            setPadding(14.dp(), 10.dp(), 14.dp(), 10.dp())
            addView(label("${st[0]}", 40f, INK, true))
            val per = material?.perMark ?: 1
            val det = buildString {
                append("st ${material?.name ?: ""}\n")
                if (per > 1) append("${st[4]} markeringar × $per\n")
                append("${st[1]} auto · ${st[2]} tillagda · ${st[3]} borttagna")
            }
            addView(label(det, 12f, MUTED).apply { setPadding(12.dp(), 0, 0, 0) })
        }
        col.addView(sum)
        val preview = label("", 12f, MUTED).apply { typeface = Typeface.MONOSPACE; setPadding(0, 10.dp(), 0, 0) }
        fieldViews = HashMap()
        val names = mapOf("article" to "Artikelnummer", "batch" to "Batchnummer", "description" to "Benämning",
            "location" to "Lagerplats", "comment" to "Kommentar")
        for (k in fieldKeys) {
            col.addView(label(names[k] ?: k, 12f, MUTED, true), lp(top = 10))
            val et = EditText(this).apply {
                setText(fields[k] ?: ""); setSingleLine()
                if (k == "batch") inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        fields[k] = s?.toString() ?: ""
                        Store.setField(this@MainActivity, k, fields[k] ?: "")
                        preview.text = report(time)
                    }
                })
            }
            fieldViews[k] = et
            col.addView(et)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(btn("Fota etikett") { takePhoto(REQ_LABEL) }, lp(0, weight = 1f, right = 8))
        row.addView(btn("Kopiera") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Räkning", report(time))); toast("Kopierat")
        }, lp(0, weight = 1f))
        col.addView(row, lp(top = 12))
        preview.text = report(time)
        col.addView(preview)
        val scroll = ScrollView(this).apply { addView(col) }

        val dlg = AlertDialog.Builder(this)
            .setTitle("Resultat")
            .setView(scroll)
            .setPositiveButton("Spara", null)
            .setNeutralButton("Dela", null)
            .setNegativeButton("Tillbaka", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                if (save(time)) { toast("Sparat i historiken"); dlg.dismiss() }
            }
            dlg.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener { share(time) }
        }
        dlg.setOnDismissListener { fieldViews = HashMap() }
        dlg.show()
    }

    private fun save(time: String): Boolean {
        val st = stats()
        val bmp = exportBitmap(time)
        var path = ""
        if (bmp != null) {
            val dir = File(filesDir, "rakningar").apply { mkdirs() }
            val f = File(dir, "rakning_${System.currentTimeMillis()}.jpg")
            try { FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }; path = f.absolutePath }
            catch (e: Exception) { toast("Kunde inte spara bilden") }
        }
        Store.addHistory(this, HistoryEntry(
            time, material?.name ?: "", fields["article"].orEmpty(), fields["batch"].orEmpty(),
            fields["description"].orEmpty(), fields["location"].orEmpty(), fields["comment"].orEmpty(),
            st[4], material?.perMark ?: 1, st[0], path,
        ))
        return true
    }

    private fun share(time: String) {
        val bmp = exportBitmap(time)
        val i = Intent(Intent.ACTION_SEND)
        i.putExtra(Intent.EXTRA_TEXT, report(time))
        i.putExtra(Intent.EXTRA_SUBJECT, "Räkning ${fields["article"].orEmpty()} ${fields["batch"].orEmpty()}".trim())
        if (bmp != null) {
            val f = File(cacheDir, "rakning.jpg")
            try {
                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                i.type = "image/jpeg"
                i.putExtra(Intent.EXTRA_STREAM, uri)
                i.clipData = ClipData.newRawUri("", uri)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { i.type = "text/plain" }
        } else i.type = "text/plain"
        try { startActivity(Intent.createChooser(i, "Dela räkning")) } catch (e: ActivityNotFoundException) { toast("Ingen app att dela till") }
    }

    // ================= historik =================
    private fun showHistory() {
        val list = Store.history(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20.dp(), 8.dp(), 20.dp(), 8.dp()) }
        if (list.isEmpty()) col.addView(label("Inga sparade räkningar ännu.", 14f, MUTED))
        for (h in list) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(0, 10.dp(), 0, 10.dp())
                addView(label("${h.total} st · ${h.material}", 16f, INK, true))
                addView(label(listOf(h.time, h.article.ifBlank { null }?.let { "art $it" }, h.batch.ifBlank { null }?.let { "batch $it" },
                    h.location.ifBlank { null }).filterNotNull().joinToString(" · "), 13f, MUTED))
                setOnClickListener { shareHistory(h) }
            }
            col.addView(item)
            col.addView(View(this).apply { setBackgroundColor(LINE) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
        if (list.isNotEmpty()) col.addView(label("Tryck på en rad för att dela den.", 12f, MUTED), lp(top = 8))
        val b = AlertDialog.Builder(this).setTitle("Historik").setView(ScrollView(this).apply { addView(col) })
            .setNegativeButton("Stäng", null)
        if (list.isNotEmpty()) {
            b.setPositiveButton("Exportera CSV") { _, _ -> exportCsv(list) }
            b.setNeutralButton("Rensa") { _, _ ->
                AlertDialog.Builder(this).setMessage("Rensa hela historiken?")
                    .setPositiveButton("Rensa") { _, _ ->
                        list.forEach { if (it.image.isNotBlank()) File(it.image).delete() }
                        Store.clearHistory(this); toast("Historiken rensad")
                    }.setNegativeButton("Avbryt", null).show()
            }
        }
        b.show()
    }

    private fun shareHistory(h: HistoryEntry) {
        val txt = buildString {
            append("RÄKNING – ${h.material}\nDatum:       ${h.time}\n")
            append("Artikelnr:   ${h.article.ifBlank { "–" }}\nBenämning:   ${h.description.ifBlank { "–" }}\n")
            append("Batchnr:     ${h.batch.ifBlank { "–" }}\nLagerplats:  ${h.location.ifBlank { "–" }}\n")
            append("Antal:       ${h.total} st")
            if (h.perMark > 1) append("  (${h.marks} markeringar × ${h.perMark})")
            if (h.comment.isNotBlank()) append("\nKommentar:   ${h.comment}")
        }
        val i = Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_TEXT, txt); type = "text/plain" }
        val f = File(h.image)
        if (h.image.isNotBlank() && f.exists()) {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            i.type = "image/jpeg"; i.putExtra(Intent.EXTRA_STREAM, uri)
            i.clipData = ClipData.newRawUri("", uri); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(i, "Dela räkning")) } catch (e: ActivityNotFoundException) { toast("Ingen app att dela till") }
    }

    private fun exportCsv(list: List<HistoryEntry>) {
        fun q(s: String) = if (s.contains(';') || s.contains('"') || s.contains('\n')) "\"" + s.replace("\"", "\"\"") + "\"" else s
        val sb = StringBuilder("﻿Datum;Material;Artikelnr;Benämning;Batch;Lagerplats;Markeringar;Per markering;Antal;Kommentar\n")
        for (h in list) {
            sb.append(listOf(h.time, h.material, h.article, h.description, h.batch, h.location,
                h.marks.toString(), h.perMark.toString(), h.total.toString(), h.comment).joinToString(";") { q(it) }).append("\n")
        }
        val f = File(cacheDir, "rakningar.csv")
        f.writeText(sb.toString())
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"; putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(i, "Exportera historik")) } catch (e: ActivityNotFoundException) { toast("Ingen app att dela till") }
    }
}
